from prometheus_client import Gauge, start_http_server
import time
import numpy as np
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score
from sklearn.preprocessing import StandardScaler

def evaluate_model(model, X_test, y_test):
    pred_y = model.predict_proba(X_test)[:, 1]
    pred_classes = np.where(pred_y > 0.5, 1, 0)
    f1 = f1_score(y_test, pred_classes)
    precision = precision_score(y_test, pred_classes)
    recall = recall_score(y_test, pred_classes)
    auc = roc_auc_score(y_test, pred_classes)
    return f1, precision, recall, auc

# Функция для разбиения данных на батчи по 50 записей
def get_batches(X, y, batch_size=50):
    for i in range(0, len(X), batch_size):
        yield X[i:i + batch_size], y[i:i + batch_size]

# Функция для обновления метрик на основе предсказаний батча
def update_metrics():
    batches = get_batches(X, y)
    for i, (X_batch, y_batch) in enumerate(batches):
        if len(X_batch) == 0:  # Проверка на пустой батч
            break
        # Предсказание для текущего батча
        pred_y = cat_model.predict_proba(X_batch)[:, 1]
        pred_classes = np.where(pred_y > 0.5, 1, 0)
        
        # Вычисление метрик
        f1 = f1_score(y_batch, pred_classes)
        precision = precision_score(y_batch, pred_classes)
        recall = recall_score(y_batch, pred_classes)
        auc = roc_auc_score(y_batch, pred_classes)
        
        # Обновление метрик в Prometheus
        f1_gauge.set(f1)
        precision_gauge.set(precision)
        recall_gauge.set(recall)
        auc_gauge.set(auc)
        
        print(f"Batch {i + 1}: F1-score: {f1:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, AUC: {auc:.4f}")
        time.sleep(60)  # Интервал в 1 минуту

if __name__ == '__main__':
    # Запускаем HTTP сервер для Prometheus на порту 8000
    start_http_server(8000)
    print("Prometheus metrics server started on port 8000")

    # Инициализация метрик Prometheus
    f1_gauge = Gauge('model_f1_score', 'F1-score of the model')
    precision_gauge = Gauge('model_precision_score', 'Precision of the model')
    recall_gauge = Gauge('model_recall_score', 'Recall of the model')
    auc_gauge = Gauge('model_auc_score', 'AUC of the model')
    
    # Загрузка модели
    cat_model = joblib.load('cat_model.pkl')
    
    # Загрузка и подготовка данных
    dataset = pd.read_csv('winequality-red.zip', sep=';')
    X = dataset.drop('quality', axis=1)
    y = dataset['quality'].apply(lambda x: 1 if x > 6 else 0)
    
    # Стандартизация признаков
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    # Запускаем цикл обновления метрик
    update_metrics()